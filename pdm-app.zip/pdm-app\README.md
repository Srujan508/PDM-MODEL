# Predictive Maintenance System (PDM)

Minimal runnable app with Backend (Node + Express) and Frontend (HTML/CSS/JS). No DB.

## Structure

- backend
- frontend

Backend serves the frontend statically at http://localhost:4000/.

## Setup & Run

1. Open a terminal
2. Run:

```
cd backend
npm install
node server.js
```

3. Open http://localhost:4000/ in your browser.

## Environment

Create `.env` in `backend/` by copying `.env.example` and fill in values.

Required:

- PORT (default 4000)
- JWT_SECRET
- MODEL_URL (the hosted model endpoint)
- MODEL_API_KEY (if required by your model)

## Seeded Admin User

- Email: admin@example.com
- Password: pass1234

## API Endpoints (summary)

- POST /api/auth/login
- GET /api/machines
- GET /api/machines/:id/history
- POST /api/predict
- GET /health

## Sample curl

- Login

```
curl -s -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"pass1234"}'
```

- Get machines (replace TOKEN)

```
curl -s http://localhost:4000/api/machines \
  -H "Authorization: Bearer TOKEN"
```

- Predict (replace TOKEN and machine)

```
curl -s -X POST http://localhost:4000/api/predict \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "machine_id":"M1",
    "params": {"vibration":0.7, "temperature":0.4, "pressure":0.6}
  }'
```

## Notes

- Backend logs model request/response summaries.
- If the hosted model fails or times out (3s, up to 2 retries), backend returns a deterministic fallback.
